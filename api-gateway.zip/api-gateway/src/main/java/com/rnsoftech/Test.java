package com.rnsoftech;

public class Test {
    public static void main(String[] args) {
        int arr[] = {12, 34, 8888, 56, 66, 8888, 89, 888, 788, 8888};
        //int arr
        int max = arr[0];
        int count = 1;

        // find max, and count of repeated max number
        for (int i=0; i<arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            } else if (arr[i] == max) {
                count++;
            }
        }
        System.out.println("Maximum: " + max);
        System.out.println("Count: " + count);
    }
}
