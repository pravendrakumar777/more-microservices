package com.rnsoftech.config;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
    @Bean
    public GroupedOpenApi apiGatewayAPI() {
        return GroupedOpenApi.builder()
                .group("api-gateway")
                .pathsToMatch("/api/**")
                .build();
    }
    @Bean
    public GroupedOpenApi userServiceAPI() {
        return GroupedOpenApi.builder()
                .group("user-service")
                .pathsToMatch("/users/**")
                .build();
    }

    @Bean
    public GroupedOpenApi hotelServiceAPI() {
        return GroupedOpenApi.builder()
                .group("hotel-service")
                .pathsToMatch("/hotels/**")
                .build();
    }

    @Bean
    public GroupedOpenApi ratingServiceAPI() {
        return GroupedOpenApi.builder()
                .group("rating-service")
                .pathsToMatch("/ratings/**")
                .build();
    }

    @Bean
    public GroupedOpenApi allServicesApi() {
        return GroupedOpenApi.builder()
                .group("all-services")
                .pathsToMatch("/**")
                .build();
    }
}
