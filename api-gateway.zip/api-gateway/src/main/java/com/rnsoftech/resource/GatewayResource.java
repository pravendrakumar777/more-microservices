package com.rnsoftech.resource;

import com.rnsoftech.service.GatewayService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GatewayResource {

    private final Logger log = LoggerFactory.getLogger(GatewayResource.class);
    private final GatewayService gatewayService;
    public GatewayResource(GatewayService gatewayService) {
        this.gatewayService = gatewayService;
    }

    @PostMapping("/api/create-user")
    public ResponseEntity<String> createUser(@RequestBody Object user) {
        log.info("Rest call from api-gateway to create user {}: ", user);
        return gatewayService.createUser(user);
    }

    @PostMapping("/api/create-hotel")
    public ResponseEntity<String> createHotel(@RequestBody Object hotel) {
        log.info("Rest call from api-gateway to createHotel {}: ", hotel);
        return gatewayService.createHotel(hotel);
    }

    @PostMapping("/api/create-rating")
    public ResponseEntity<String> createRating(@RequestBody Object rating) {
        log.info("Rest call from api-gateway to createRating {}: ", rating);
        return gatewayService.createRating(rating);
    }
}
