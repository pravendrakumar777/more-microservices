package com.rnsoftech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
@EnableDiscoveryClient
public class ApiGatewayApplication {
	// http://localhost:8084/swagger-ui/index.html#/

	// http://localhost:8084/users
	// http://localhost:8084/hotels
	// http://localhost:8084/ratings
	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayApplication.class, args);
	}
}
