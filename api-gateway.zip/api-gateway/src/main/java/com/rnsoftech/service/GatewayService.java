package com.rnsoftech.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
@Service
public class GatewayService {

    private final Logger log = LoggerFactory.getLogger(GatewayService.class);
    private final RestTemplate restTemplate;

    public GatewayService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    private final String USER_SERVICE_URL = "http://localhost:8081/users";
    private final String HOTEL_SERVICE_URL = "http://localhost:8082/hotels";
    private final String RATING_SERVICE_URL = "http://localhost:8083/ratings";

    // create user in user-service
    public ResponseEntity<String> createUser(Object user) {
        log.info("Service Request to call createUser {}: ", user);
        HttpEntity<Object> entity = new HttpEntity<>(user);
        return restTemplate.exchange(USER_SERVICE_URL, HttpMethod.POST, entity, String.class);
    }

    // create hotel in hotel-service
    public ResponseEntity<String> createHotel(Object hotel) {
        log.info("Service Request to call createHotel {}: ", hotel);
        HttpEntity<Object> entity = new HttpEntity<>(hotel);
        return restTemplate.exchange(HOTEL_SERVICE_URL, HttpMethod.POST, entity, String.class);
    }

    // create rating in rating-service
    public ResponseEntity<String> createRating(Object rating) {
        log.info("Service Request to call createRating {}: ", rating);
        HttpEntity<Object> entity = new HttpEntity<>(rating);
        return restTemplate.exchange(RATING_SERVICE_URL, HttpMethod.POST, entity, String.class);
    }
}
