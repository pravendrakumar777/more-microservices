package com.rnsoftech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class RatingServiceApplication {
	// Swagger URL = http://localhost:8083/swagger-ui/index.html
	public static void main(String[] args) {
		SpringApplication.run(RatingServiceApplication.class, args);
	}
}
