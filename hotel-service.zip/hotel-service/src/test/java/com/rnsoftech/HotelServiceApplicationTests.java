package com.rnsoftech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
