package com.rnsoftech;/*
 * @Created 24/04/2024 - 15:19
 * @User ${"PRAVENDRA KUMAR"}
 */

public class Hello {
    public static void main(String[] args) {
        System.out.println("HELLO PRAVENDRA");
    }
}
